#!/bin/bash
go get -v golang.org/x/tools/cmd/present

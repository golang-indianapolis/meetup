#!/bin/bash
uname -a

echo 'hello bash'
ls -nh
